﻿namespace InheritanceAndPolymorphism.Cotracts
{
    public interface IOffsiteCourse : ICourse
    {
        string Town { get; set; }
    }
}
