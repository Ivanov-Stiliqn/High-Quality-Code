﻿namespace Abstraction.Contracts
{
    internal interface ISurfaceCalculateable
    {
        double CalcSurface();
    }
}
