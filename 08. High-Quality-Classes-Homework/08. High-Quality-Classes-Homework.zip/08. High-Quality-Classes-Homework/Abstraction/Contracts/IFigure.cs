﻿namespace Abstraction.Contracts
{
    internal interface IFigure : IPerimeterCalculateable, ISurfaceCalculateable
    {
    }
}
