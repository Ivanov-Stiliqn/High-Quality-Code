﻿namespace Abstraction.Contracts
{
    internal interface IPerimeterCalculateable
    {
        double CalcPerimeter();
    }
}
